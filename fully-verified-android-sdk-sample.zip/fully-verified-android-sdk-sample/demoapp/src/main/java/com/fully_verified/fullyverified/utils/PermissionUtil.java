package com.fully_verified.fullyverified.utils;


import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

public class PermissionUtil {
    public static boolean shouldAskPermission() {
        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M);
    }

    public static boolean shouldAskPermission(Activity context, String[] permissions) {
        if (shouldAskPermission()) {
            for (String permission : permissions) {
                int permissionResult = ActivityCompat.checkSelfPermission(context, permission);
                if (permissionResult != PackageManager.PERMISSION_GRANTED) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void checkPermissions(Activity context, String[] permissions, PermissionAskListener listener) {
        if (shouldAskPermission(context, permissions)) {
            List<String> showRationale = new ArrayList<>();
            List<String> disabled = new ArrayList<>();
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    if (!ActivityCompat.shouldShowRequestPermissionRationale(context, permission)) {
                        showRationale.add(permission);
                    } else {
                        disabled.add(permission);
                    }
                }
            }
            if (showRationale.size() > 0) {
                listener.onPermissionPreviouslyDenied(showRationale.toArray(new String[showRationale.size()]));
            } else if (disabled.size() > 0) {
                listener.onPermissionDisabled(disabled.toArray(new String[disabled.size()]));
            }
        } else {
            listener.onPermissionGranted(permissions);
        }
    }

    public interface PermissionAskListener {
        /*
                * Callback to ask permission
                * */
        void onNeedPermission(String[] permission);

        /*
                * Callback on permission denied
                * */
        void onPermissionPreviouslyDenied(String[] permission);

        /*
                * Callback on permission "Never show again" checked and denied
                * */
        void onPermissionDisabled(String[] permission);

        /*
                * Callback on permission granted
                * */
        void onPermissionGranted(String[] permissions);
    }
}
