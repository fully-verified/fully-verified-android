package com.fully_verified.fullyverified;


import android.app.ActivityManager;
import android.content.Context;
import androidx.annotation.NonNull;

import com.fully_verified.fullyverifiedsdk.FullyVerified;

import java.util.List;


public class ApplicationConstants {

    private final static String TAG = ApplicationConstants.class.getSimpleName();

    public static final String ROOM_CONNECTED_ACTION = "com.fully_verified.fullyverifiedsdk.ROOM_CONNECTED_ACTION";
    public static final String ROOM_USER_STATE_NOT_ACTIVE_ACTION = "com.fully_verified.fullyverifiedsdk.ROOM_USER_STATE_NOT_ACTIVE_ACTION";
    public static final String ROOM_DISCONNECTED_ACTION = "com.fully_verified.fullyverifiedsdk.ROOM_DISCONNECTED_ACTION";
    public static final String ROOM_WAITING_ACTION = "com.fully_verified.fullyverifiedsdk.ROOM_WAITING_ACTION";
    public static final String ROOM_WAITING_ACTION_ERROR = "com.fully_verified.fullyverifiedsdk.ROOM_WAITING_ACTION_ERROR";
    public static final String ROOM_CAMERA_CHANGE_ACTION = "com.fully_verified.fullyverifiedsdk.ROOM_CAMERA_CHANGE_ACTION";

    public final static String NOTIFICATION_CHANNEL = "FullyVerifiedNotificationChannel";
    public final static String CASE_HASH = "case_hash";
    public final static String CASE_AUTH_RESPONSE = "case_auth_response";
    public final static String CASE_STATUS_RESPONSE = "case_status_response";
    public final static String CASE_STATUS_RESPONSE_ERROR_TITLE = "case_status_response_error_title";
    public final static String CASE_STATUS_RESPONSE_ERROR_MESSAGE = "case_status_response_error_message";
    public final static String ROOM_STATUS = "room_status";
    public final static String ROOM_USER_STATE = "room_user_state";
    public final static String ROOM_AUTH_CODE = "room_auth_code";
    public final static String ROOM_INFO = "room_info";
    public final static String CAMERA_TYPE = "room_camera_type";
    public final static String CAMERA_FLASH_MODE = "room_camera_flash_mode";
    public final static String APPLICATION_FIRST_LAUNCH_STAGE = "application_first_launch_stage";
    public final static String ENVIRONMENT_PRODUCTION = "app";
    public final static String ENVIRONMENT_STAGING = "swamp";
    public final static int ON_DO_NOT_DISTURB_CALLBACK_CODE = 31337;

    public static boolean appInForeground(@NonNull Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();
            if (runningAppProcesses == null) {
                return false;
            }

            for (ActivityManager.RunningAppProcessInfo runningAppProcess : runningAppProcesses) {
                if (runningAppProcess.processName.equals(context.getPackageName()) &&
                        runningAppProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isRelease(Context context) {
        return context.getString(R.string.buildType).equalsIgnoreCase("release");
    }

    public synchronized static String getEnvironment() {
//        if (isRelease(context)) {
//            return ENVIRONMENT_PRODUCTION;
//        }
        return FullyVerified.getEnvironment();
    }
}
