package com.fully_verified.fullyverified.activities;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatTextView;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.fully_verified.fullyverified.BuildConfig;
import com.fully_verified.fullyverified.R;
import com.fully_verified.fullyverified.utils.PermissionUtil;
import com.fully_verified.fullyverifiedsdk.FullyVerified;
import com.fully_verified.fullyverifiedsdk.FullyVerifiedException;
import com.fully_verified.fullyverifiedsdk.FullyVerifiedListener;
import com.fully_verified.fullyverifiedsdk.FullyVerifiedState;
import com.fully_verified.fullyverifiedsdk.utils.ApplicationConstants;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


public class CaseJoinActivity extends FullyVerifiedActivity implements FullyVerifiedListener {

    private final static String TAG = CaseJoinActivity.class.getSimpleName();
    private static final Pattern MOBILE_ID_PATTERN = Pattern.compile("[a-zA-Z0-9]{8}");
    private static final Pattern OTP_PATTERN = Pattern.compile("[0-9]{6}");
    private static final int RC_BARCODE_CAPTURE = 9001;
    private static final int REQUEST_PERMISSION_SETTING_JOIN = 10001;
    private static final int REQUEST_PERMISSION_SETTING_SCAN = 10002;

    private TextInputEditText mobileId;
    private TextInputEditText otp;
    private AppCompatButton button;

    private PermissionUtil.PermissionAskListener permissionCaseJoinAskListener = new PermissionUtil.PermissionAskListener() {
        @Override
        public void onNeedPermission(String[] permissions) {

        }

        @Override
        public void onPermissionPreviouslyDenied(final String[] permissions) {
            AlertDialog.Builder builder = new AlertDialog.Builder(CaseJoinActivity.this);
            builder.setMessage(R.string.permissions_needed_explain);
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions(CaseJoinActivity.this, permissions, 200);
                }
            });
            builder.setNegativeButton(R.string.cancel, null);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

        @Override
        public void onPermissionDisabled(String[] permissions) {
            AlertDialog.Builder builder = new AlertDialog.Builder(CaseJoinActivity.this);
            builder.setMessage(R.string.permissions_needed);
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivityForResult(intent, REQUEST_PERMISSION_SETTING_JOIN);
                }
            });
            builder.setNegativeButton(R.string.cancel, null);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

        @Override
        public void onPermissionGranted(String[] permissions) {
            joinCase();
        }
    };

    private PermissionUtil.PermissionAskListener permissionCaseScanAskListener = new PermissionUtil.PermissionAskListener() {
        @Override
        public void onNeedPermission(String[] permissions) {

        }

        @Override
        public void onPermissionPreviouslyDenied(final String[] permissions) {
            AlertDialog.Builder builder = new AlertDialog.Builder(CaseJoinActivity.this);
            builder.setMessage(R.string.permissions_needed_explain);
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions(CaseJoinActivity.this, permissions, 201);
                }
            });
            builder.setNegativeButton(R.string.cancel, null);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

        @Override
        public void onPermissionDisabled(String[] permissions) {
            AlertDialog.Builder builder = new AlertDialog.Builder(CaseJoinActivity.this);
            builder.setMessage(R.string.permissions_needed);
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivityForResult(intent, REQUEST_PERMISSION_SETTING_SCAN);
                }
            });
            builder.setNegativeButton(R.string.cancel, null);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

        @Override
        public void onPermissionGranted(String[] permissions) {
            mobileId.setText("");
            otp.setText("");
            Intent intent = new Intent(CaseJoinActivity.this, CaseScanActivity.class);
            startActivityForResult(intent, RC_BARCODE_CAPTURE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_join);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        AppCompatTextView textView = findViewById(R.id.welcome_text);
        String welcomeText = getString(R.string.welcome_text);
        String appName = getString(R.string.app_name);
        int appNameIndex = welcomeText.indexOf(appName);
        final SpannableStringBuilder sb = new SpannableStringBuilder(welcomeText);
        final StyleSpan bss = new StyleSpan(android.graphics.Typeface.BOLD);
        sb.setSpan(bss, appNameIndex, appNameIndex + appName.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        textView.setText(sb);

        Intent intent = getIntent();
        if (intent != null) {
            String caseHash = getIntent().getStringExtra("case_hash");
            Uri data = getIntent().getData();

            if (!TextUtils.isEmpty(caseHash)) {
                findCase(caseHash);
            } else if (data != null) {
                findCase(data.getLastPathSegment());
            }
        }

        mobileId = findViewById(R.id.mobileIdEditText);
        mobileId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                isValid(editable, MOBILE_ID_PATTERN, mobileId);
            }
        });
        otp = findViewById(R.id.otpEditText);
        otp.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                isValid(editable, OTP_PATTERN, otp);
            }
        });
        button = findViewById(R.id.login_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCaseJoinClick(view);
            }
        });

        if (!BuildConfig.BUILD_TYPE.equals("release")) {
            AppCompatImageButton settingsButton = findViewById(R.id.settings_button);
            settingsButton.setVisibility(View.VISIBLE);
            settingsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(CaseJoinActivity.this, SettingsActivity.class);
                    startActivity(i);
                }
            });
        }

        AppCompatButton buttonScan = findViewById(R.id.scan_button);
        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCaseScanClick(view);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("case_hash") && intent.getStringExtra("case_hash") != null) {
            findCase(getIntent().getStringExtra("case_hash"));
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent");
        setIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RC_BARCODE_CAPTURE) {
            if (resultCode == CommonStatusCodes.SUCCESS) {
                if (data != null) {
                    String caseHash = data.getStringExtra(CaseScanActivity.BarcodeObject);
                    Log.d(TAG, "Barcode read: " + caseHash);
                    findCase(caseHash);
                }
            }
        } else if (requestCode == REQUEST_PERMISSION_SETTING_JOIN) {
            PermissionUtil.checkPermissions(CaseJoinActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, permissionCaseJoinAskListener);
        } else if (requestCode == REQUEST_PERMISSION_SETTING_SCAN) {
            PermissionUtil.checkPermissions(CaseJoinActivity.this, new String[]{Manifest.permission.CAMERA}, permissionCaseScanAskListener);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        int grantCheck = 0;
        for (int grantResult : grantResults) {
            grantCheck += grantResult;
        }

        if (requestCode == 200 && grantCheck == 0) {
            joinCase();
        } else if (requestCode == 201 && grantCheck == 0) {
            scanCase();
        }
    }

    private boolean isValid(CharSequence charSequence, Pattern pattern, EditText editText) {
        return charSequence.toString().matches(pattern.pattern()) && charSequence.length() > 0;
    }

    public void onCaseJoinClick(View view) {
        if (isValid(mobileId.getText(), MOBILE_ID_PATTERN, mobileId) && isValid(otp.getText(), OTP_PATTERN, otp)) {
            List<String> permissions = new ArrayList<>();
            permissions.add(Manifest.permission.CAMERA);
            permissions.add(Manifest.permission.RECORD_AUDIO);
            PermissionUtil.checkPermissions(CaseJoinActivity.this, permissions.toArray(new String[permissions.size()]), permissionCaseJoinAskListener);
        } else {
            showWrongDataDialog(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }, getString(R.string.verify_join_error_title), getString(R.string.verify_join_error_message));
        }
    }

    private void joinCase() {
        FullyVerified fullyVerified = FullyVerified.startVerification(
                mobileId.getText().toString(),
                otp.getText().toString(),
                CaseJoinActivity.this,
                this
        );

// variant 2 - start verification that throws exception when error
//        try {
//            FullyVerified fullyVerified = FullyVerified.startVerification(
//                    mobileId.getText().toString(),
//                    otp.getText().toString(),
//                    CaseJoinActivity.this,
//                    this,
//                    false
//            );
//        } catch (FullyVerifiedException e) {
//            e.printStackTrace();
//        }
    }

    private void scanCase() {
        mobileId.setText("");
        otp.setText("");
        Intent intent = new Intent(CaseJoinActivity.this, CaseScanActivity.class);
        startActivityForResult(intent, RC_BARCODE_CAPTURE);
    }

    public void onCaseScanClick(View view) {
        PermissionUtil.checkPermissions(CaseJoinActivity.this, new String[]{Manifest.permission.CAMERA}, permissionCaseScanAskListener);
    }


    private void showWrongDataDialog(DialogInterface.OnClickListener onClickListener, @Nullable String title, @Nullable String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(CaseJoinActivity.this);
        if (title != null) {
            builder.setTitle(title);
        }
        if (message != null) {
            builder.setMessage(message);
        }
        builder.setPositiveButton(R.string.ok, onClickListener);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void findCase(String caseHash) {
        FullyVerified fullyVerified = FullyVerified.startVerification("358eecfccc997407805042fee5df49d47531c99c4ea5c7a5129e7f3bfa290a6a15503573fc7f5bf8e879a185dbc7b5e6438d2ed082b37eae3fdee70c5f956fbd", CaseJoinActivity.this, this);
    }

    @Override
    public void onConnected(String verificationId) {
        Log.d(TAG, String.format("Listener onConnected %s", verificationId));
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("case_hash", verificationId);
        editor.apply();
    }

    @Override
    public void onVerificationStateChange(String verificationId, FullyVerifiedState state) {
        Log.d(TAG, String.format("Listener onVerificationStateChange %s state %s", verificationId, state));
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("case_hash", verificationId);
        editor.apply();
    }

    @Override
    public void onDisconnect(String verificationId) {
        Log.d(TAG, String.format("Listener onDisconnected %s", verificationId));
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("case_hash");
        editor.apply();
    }
}
