package com.fully_verified.fullyverified.messaging;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.preference.PreferenceManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;

import android.util.Log;

import com.fully_verified.fullyverified.R;
import com.fully_verified.fullyverified.activities.CaseJoinActivity;
import com.fully_verified.fullyverifiedsdk.FullyVerified;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class MessageListenerService extends FirebaseMessagingService {

    private final static String TAG = MessageListenerService.class.getSimpleName();
    public static final int NOTIFICATION_ID = 1;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.e(TAG, "Message received...");

        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message type: " + remoteMessage.getMessageType());
            Log.d(TAG, "Message twilio payload: " + remoteMessage.getData());
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getData().containsKey("body")) {
            Log.e(TAG, "Message Notification Body: " + remoteMessage.getData().get("body"));
            sendNotification(remoteMessage.getData());
        }
    }

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "New messaging token: " + token);
        FullyVerified.registerMessagingToken(this, token);
    }

    private void sendNotification(Map<String, String> data) {
        String messageBody = data.get("body");
        String caseHash = FullyVerified.getCaseHash(this, data);
        Log.d(TAG, "caseHash: " + caseHash);
        Intent resultIntent = new Intent(this, CaseJoinActivity.class);
//        Intent resultIntent = new Intent(this, com.fully_verified.fullyverifiedsdk.activities.FullyVerified.class);
//        resultIntent.setAction("PUSH_NOTIFICATION_CASE");
        resultIntent.putExtra("case_hash", caseHash);
//        resultIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addNextIntentWithParentStack(resultIntent);

        PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

//        PendingIntent pendingIntent = PendingIntent.getActivity(
//                this,
//                0,
//                new Intent(this, FullyVerifiedActivity.class),
//                PendingIntent.FLAG_UPDATE_CURRENT);

        String channelId = getString(R.string.app_name);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(this, channelId)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .setSmallIcon(R.drawable.ic_stat_name)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(messageBody))
                        .setContentTitle(channelId)
                        .setContentText(messageBody)
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(channelId, channelId, NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
            }

            notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build());
        }
    }
}
