package com.fully_verified.fullyverified.activities;


import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;
import com.fully_verified.fullyverified.R;

import io.sentry.Sentry;

public class SplashActivity extends AppCompatActivity implements InstallReferrerStateListener {

    private final static String TAG = SplashActivity.class.getSimpleName();

    final static String APPLICATION_FIRST_LAUNCH_STAGE = "application_first_launch_stage";

    private InstallReferrerClient referrerClient = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(SplashActivity.this);
        int firstLaunchStage = preferences.getInt(APPLICATION_FIRST_LAUNCH_STAGE, 0);

        Intent intent = getIntent();
        String action = intent.getAction();
        Uri data = intent.getData();
        Log.d(TAG, action);
        if (data != null) {
            Log.d(TAG, data.getPath());
        }

        if (firstLaunchStage == 0) {
            referrerClient = InstallReferrerClient.newBuilder(SplashActivity.this).build();
            referrerClient.startConnection(SplashActivity.this);
        } else {
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    Intent emptyIntent = new Intent(SplashActivity.this, CaseJoinActivity.class);
                    startActivity(emptyIntent);
                    finish();
                }
            };

            Handler handler = new Handler();
            handler.postDelayed(runnable, 1500);
        }
    }

    @Override
    public void onInstallReferrerSetupFinished(int responseCode) {
        String referrer = null;
        switch (responseCode) {
            case InstallReferrerClient.InstallReferrerResponse.OK:
                try {
                    Log.v(TAG, "InstallReferrer connected");
                    ReferrerDetails response = referrerClient.getInstallReferrer();
                    Log.d(TAG, "Response: " + response);
                    if (response.getInstallReferrer() != null) {
                        referrer = response.getInstallReferrer();
                        Log.d(TAG, "Referrer: " + referrer);
                    }
                    referrerClient.endConnection();
                } catch (RemoteException e) {
                    Sentry.capture(e);
                }
                break;
            case InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED:
                Log.w(TAG, "InstallReferrer not supported");
                break;
            case InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE:
                Log.w(TAG, "Unable to connect to the service");
                break;
            default:
                Log.w(TAG, "responseCode not found.");
        }

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(SplashActivity.this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(APPLICATION_FIRST_LAUNCH_STAGE, 1);
        editor.apply();

        final String finalReferrer = referrer;
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, CaseJoinActivity.class);
                if (finalReferrer != null && !finalReferrer.isEmpty()) {
                    Log.d(TAG, finalReferrer);
                    Uri uri = Uri.parse(finalReferrer);
                    if (uri.isAbsolute()) {
                        intent.setData(uri);
                    }
                }
                startActivity(intent);
                finish();
            }
        };

        Handler handler = new Handler();
        handler.postDelayed(runnable, 1500);
    }

    @Override
    public void onInstallReferrerServiceDisconnected() {

    }
}
