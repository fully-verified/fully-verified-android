package com.fully_verified.fullyverified.activities;

import android.content.res.Resources;
import androidx.core.content.res.ResourcesCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.fully_verified.fullyverified.ApplicationConstants;

import io.sentry.Sentry;


public abstract class FullyVerifiedActivity extends AppCompatActivity {

    private final static String TAG = FullyVerifiedActivity.class.getSimpleName();

/*    @Override
    protected void onResume() {
        super.onResume();
        View activityView = findViewById(com.fully_verified.fullyverifiedsdk.R.id.activity);
        if (activityView != null) {
            String backgroundName = getBackgroundFileName(ApplicationConstants.getEnvironment());
            try {
                activityView.setBackground(ResourcesCompat.getDrawable(
                        getResources(),
                        getResources().getIdentifier(backgroundName, "drawable", this.getPackageName()),
                        null));
            } catch (Resources.NotFoundException e) {
                Log.e(TAG, "Cannot find background: " + backgroundName + "with exception: " + e);
                Sentry.capture(e);
            }
        }
    }*/

    private String getBackgroundFileName(String environment) {
        if (environment != null) {
            environment = environment.replace("-", "_");
            return environment + "_background_classic";
        } else {
            return "background_classic";
        }
    }
}
