package com.fully_verified.fullyverified.activities;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.util.Log;

import com.fully_verified.fullyverified.R;
import com.fully_verified.fullyverifiedsdk.FullyVerified;
import com.fully_verified.fullyverifiedsdk.FullyVerifiedEnvironment;


public class SettingsActivity extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener {

    private static final String REGISTRATION_ID = "FULLYVERIFIED_FIREBASE_REGISTRATION_ID";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(this);
        getFragmentManager().beginTransaction().replace(android.R.id.content, new MyPreferenceFragment()).commit();
    }

    public static class MyPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(final Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.preferences);
        }
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (key.equalsIgnoreCase("env")) {
            String newEnvironment = sharedPreferences.getString(key, FullyVerifiedEnvironment.LIVE);
            FullyVerified.setEnvironment(this, newEnvironment);
            setFirebaseToken();
        }
    }

    private void setFirebaseToken() {
        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String id = prefs.getString(REGISTRATION_ID, null);
        if (id != null) {
            FullyVerified.registerMessagingToken(this, id);
        }
    }
}
