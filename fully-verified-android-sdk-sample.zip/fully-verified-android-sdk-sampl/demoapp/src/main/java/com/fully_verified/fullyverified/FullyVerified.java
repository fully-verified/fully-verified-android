package com.fully_verified.fullyverified;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.preference.PreferenceManager;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

import com.fully_verified.fullyverifiedsdk.FullyVerifiedEnvironment;

import io.sentry.Sentry;
import io.sentry.android.AndroidSentryClientFactory;


public class FullyVerified extends MultiDexApplication {

    private final static String TAG = FullyVerified.class.getSimpleName();
    final static String NOTIFICATION_CHANNEL = "FullyVerifiedNotificationChannel";

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Sentry.init(getSentryDSN().toString(), new AndroidSentryClientFactory(this));

        if (!BuildConfig.BUILD_TYPE.equals("release")) {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String newEnvironment = sharedPreferences.getString("env", FullyVerifiedEnvironment.LIVE);
            com.fully_verified.fullyverifiedsdk.FullyVerified.setEnvironment(this, newEnvironment);
        } else {
            com.fully_verified.fullyverifiedsdk.FullyVerified.setEnvironment(this, FullyVerifiedEnvironment.LIVE);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            String description = "Notifications regarding our products";
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL, getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
            // Configure the notification channel.
            notificationChannel.setDescription(description);
            notificationChannel.enableLights(true);
            // Sets the notification light color for notifications posted to this
            // channel, if the device supports this feature.
            notificationChannel.setLightColor(Color.RED);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
    }

//    @Override
//    public void onTerminate() {
//        Log.d(TAG, "onTerminate");
//        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(getApplicationContext()));
//        dispatcher.cancelAll();
//        super.onTerminate();
//    }

    private StringBuilder getSentryDSN() {
        String protocol = "https";
        String publicKey = "637dc1d75bc1401ba8ddc50a4c2b58b6";
        String privateKey = "1d5ff81836f541bd99b6dace6a3f6b40";
        String host = "sentry.inprojects.pl";
        String projectId = "14";
        String projectOptions = "verify_ssl=0";

        StringBuilder sb = new StringBuilder();
        sb.append(protocol);
        sb.append("://");
        sb.append(publicKey);
        sb.append(":");
        sb.append(privateKey);
        sb.append("@");
        sb.append(host);
        sb.append("/");
        sb.append(projectId);
        sb.append("?");
        sb.append(projectOptions);
        return sb;
    }
}
